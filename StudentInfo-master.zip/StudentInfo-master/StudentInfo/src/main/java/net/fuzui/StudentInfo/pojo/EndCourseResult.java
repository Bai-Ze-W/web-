package net.fuzui.StudentInfo.pojo;

public class EndCourseResult {
	

}
